
#ifndef __STACK_TRACE_H__
#define __STACK_TRACE_H__ 1

void stack_trace(void);
int  stack_trace_on_crash(void);

#endif
